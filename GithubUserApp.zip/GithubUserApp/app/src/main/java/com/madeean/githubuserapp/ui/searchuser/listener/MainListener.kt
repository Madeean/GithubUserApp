package com.madeean.githubuserapp.ui.searchuser.listener

import com.madeean.githubuserapp.ui.searchuser.adapter.MainRepresentation

interface MainListener {
    fun onItemClickListener(data: MainRepresentation)
}